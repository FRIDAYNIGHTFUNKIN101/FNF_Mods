 __                 /                                  
/ _   _ |_ |_ .  _                                     
\__) (- |_ |_ | | )                                    
                                                       
 __                                                    
|_   _  _  _  |                                        
|   |  (- (_| |( \/                                    
                 /                                     
                                                       
 _   _     _                                           
(_) | )   (_|                                          
                                                       
 __                                                    
|_   _ .  _|  _        _  .  _  |_  |_       _  _  |_  
|   |  | (_| (_| \/   | ) | (_) | ) |_   \/ (- (_| | ) 
                 /          _/           /             

HEY
Thanks for downloadin Friday Night FUNKIN'
If you downloaded this from any other place than ninja-muffin24.itch.io/FUNKIN
You might be in DANGER!!! 

The Itch.io release is the only official source for the desktop (PC, Mac, Linux) versions of the game!
As of right now, the game is FREE! If you paid for it, you got SCAMMED!

Now that that's out of the way....
THANKS FOR DOWNLOADIN. 

#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-
    PERMISSIONS XDDDD
#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-

Little info, you have FULL PERMISSION to stream, letsplay, meme, shitpost, do WHATEVER you want with the game.
Use the music in videos you do, use art, ANYTHING. GO CRAZY BRO.

If you do make any sort of video, it would be a bro move if you linked the game and spread the word

Play On Newgrounds - https://www.newgrounds.com/portal/view/770371
Support on Itch.io - https://ninja-muffin24.itch.io/funkin

If not no biggie we don't fully hate you only kinda no biggie.


#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-
    INFO AND LINKS
#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-

If you wanna dig around, the game is fully open source on Github
https://github.com/ninjamuffin99/Funkin

It's made in Haxe / HaxeFlixel

MUSIC IS ON SPOTIFY AND BANDCAMP AND EVERYWHERE ELSE PROB TOO
https://kawaisprite.bandcamp.com/album/friday-night-funkin-ost-vol-1


#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-
    FINAL WORDS / CREDITS
#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-

Friday Night Funkin' is made by ninjamuffin99 (programmer), PhantomArcade (animator), kawaisprite (musician), and evilsk8r (artist)

https://twitter.com/ninja_muffin99
https://twitter.com/phantomarcade3k
https://twitter.com/kawaisprite
https://twitter.com/evilsk8r

Pico is created by Tom Fulp
Skid and Pump are created by SrPelo
BassetFilms did music for lemon monster songs


Final important thing, this is made with the support and love to and from Newgrounds.com.
Go to newgrounds, we love newgrounds. newgrounds good. How many times do I gotta damn say it. Newgrounds newgrounds newgrounds newgrounds
I love Tom Fulp.

- Cameron ♪(´▽｀)

##################################################################################
                                                                                  
 _   _   _____   _      _    ____   ____     ___    _   _   _   _   ____    ____  
| \ | | | ____| | |    | |  / ___| |  _ \   / _ \  | | | | | \ | | |  _ \  / ___| 
|  \| | |  _|   | | /\ | | | |  _  | |_) | | | | | | | | | |  \| | | | | | \___ \ 
| |\  | | |___   \ V  V /  | |_| | |  _ <  | |_| | | |_| | | |\  | | |_| |  ___) |
|_| \_| |_____|   \_/\_/    \____| |_| \_\  \___/   \___/  |_| \_| |____/  |____/ 
 _       _  _     ___    ___       __              _       _  _       _        _  
|_ |  | |_ |_) \_/ | |_|  |  |\ | /__     |_      |_ |  | |_ |_) \_/ / \ |\ | |_  
|_  \/  |_ | \  |  | | | _|_ | \| \_| o   |_)\/   |_  \/  |_ | \  |  \_/ | \| |_ o
                                      /      /                                    
                                                                                  
##################################################################################
i stole this from stamper.